﻿if (typeof uui === 'undefined') {
	var script = document.createElement('script');
	script.src = "https://cdn.jsdelivr.net/npm/@umbraco-ui/uui@latest/dist/uui.min.js";
	document.head.appendChild(script);
}